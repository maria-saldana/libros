JS
var target=document.queryselector("canvas");
var ctx = target.getcontext("2d");
//Guardamos el estado del contexto
ctx.save();
//Restauramos el ultimo contexto guardado
ctx.restore();
//Pintamos otro retangulo
ctx.fillRect(200,50,100,100);
var gco= [ 'copy','lighter','destination-atop','destination-in','destiantion-out','destination-over','souce-over','xor' ] ;
for(var x = 0 ; x < 11 ; x++){
  var canvas = document.createElement("canvas");
  canvas .setAttribute("width","100");
  canvas .setAttribute("height","75");
  canvas.style.border="1px solid #000";
  canvas.style.margin="5px";
  var ctx = canvas.getContext("2d");
  //Pintamos un retangulo rojo
  ctx.globalCompositeoperation= "source-over";
  ctx.fillStyle = "#0060c0";
  ctx.fillRect(5,5,30,30);
  //Pintamos otro retangulo
  ctx.globalCompositeoperation= gco [ x ];
  ctx.fillStyle = "lightgray";
  ctx.fillRect(15,15,30,30);
  //Pintamos el nombre del valor que estamos aplicando
 ctx.globalCompositeoperation= "source-over";
 ctx.fillStyle = "#000";
  ctx.fort = "bold 11px arial";
  ctx.textAlign = "center";
  ctx.fillText(gco[ x ],50,65);
  //Añadimos el objetivo canvas al body
  document.body.appendChild(canvas)
  var contenedor; 

function Crear_div(){
    var elemento_div   = document.createElement("div");
    elemento_div.classList.add('insertado'); //Esto es para identificarlo después

    var texto_div = document.createTextNode("Nuevo div");
    elemento_div.appendChild(texto_div);

    contenedor.appendChild(elemento_div);
}

function ModificarContenido(evento){
    var ele_clickado = evento.target;
    // El if es opcional (si solo quieres que funcione en el ementos insertados, por ejemplo)
    if (ele_clickado.classList.contains('insertado')) {
        ele_clickado.innerHTML = 'Texto modificado';
    }

}

// He cambiado de nombre tu función asignarEventos. Ver nota al margen
function principal(){
    if (document['readyState'] == 'complete') {
        contenedor = document.querySelector('.contenedor');
        contenedor.addEventListener('click', ModificarContenido);
        setTimeout(Crear_div, 500);
    }

}

document.addEventListener('readystatechange', asignarEventos, false);
  

  

